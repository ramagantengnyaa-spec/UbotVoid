import asyncio

from userbot import CMD_HELP, StartTime, bot
from userbot.utils import bash, edit_or_reply, zelda_cmd

dosanikmat = "https://telegra.ph/file/06204b7e3ac9f38498d38.jpg"
cuddlenuddes = "https://telegra.ph/file/bb73543055ebc611ef158.jpg"
creamcheese = "https://telegra.ph/file/f068149c887950ecba499.jpg"
rahimanget = "https://telegra.ph/file/798ad0d7cad96385e4fea.jpg"
puresex = "https://telegra.ph/file/8bb19361002fb6dd666ca.jpg"
justmiss = "https://telegra.ph/file/dd7edd4f9a8620529b997.jpg"
babysweat = "https://telegra.ph/file/c4f5a2b210d8e036ab06f.jpg"
cussonsbaby = "https://telegra.ph/file/112d23dcbec66eb4f588d.jpg"

@zelda_cmd(pattern="cdn (.*)")
async def amireallycontent(content):
    user = await bot.get_me()
    capt = str(content.pattern_match.group(1).split(" ", 2)[0])
    link = str(content.pattern_match.group(1).split(" ", 2)[1])
    capti = capt.replace(".", " ")
    thumb = dosanikmat
    output = (
        f"**{capti}**\n\n"
        f"⬇️ KLIK UNTUK MENONTON ⬇️\n"
        f"{link}\n\n"
        f"-----------------------------------"
        f"\n📌 **Open Paid Promote**\n"
        f"Info : @Mtchacream"
    )
    if thumb:
        try:
            logo = thumb
            await content.delete()
            msg = await bot.send_file(content.chat_id, logo, caption=output)
            await asyncio.sleep(300)
        except BaseException:
            await content.edit(
                output + "\n\n ***Logo yang diberikan tidak valid."
                "\nPastikan link diarahkan ke gambar logo**"
            )
    else:
        await edit_or_reply(content, output)


@zelda_cmd(pattern="ccn (.*)")
async def amireallycontent(content):
    user = await bot.get_me()
    capt = str(content.pattern_match.group(1).split(" ", 2)[0])
    link = str(content.pattern_match.group(1).split(" ", 2)[1])
    capti = capt.replace(".", " ")
    thumb = cuddlenuddes
    output = (
        f"**{capti}**\n\n"
        f"⬇️ KLIK UNTUK MENONTON ⬇️\n"
        f"{link}\n\n"
        f"-----------------------------------"
        f"\n📌 **Open Paid Promote**\n"
        f"Info : @Mtchacream"
    )
    if thumb:
        try:
            logo = thumb
            await content.delete()
            msg = await bot.send_file(content.chat_id, logo, caption=output)
            await asyncio.sleep(300)
        except BaseException:
            await content.edit(
                output + "\n\n ***Logo yang diberikan tidak valid."
                "\nPastikan link diarahkan ke gambar logo**"
            )
    else:
        await edit_or_reply(content, output)
        
        
@zelda_cmd(pattern="ccc (.*)")
async def amireallycontent(content):
    user = await bot.get_me()
    capt = str(content.pattern_match.group(1).split(" ", 2)[0])
    link = str(content.pattern_match.group(1).split(" ", 2)[1])
    capti = capt.replace(".", " ")
    thumb = creamcheese
    output = (
        f"**{capti}**\n\n"
        f"⬇️ KLIK UNTUK MENONTON ⬇️\n"
        f"{link}\n\n"
        f"-----------------------------------"
        f"\n📌 **Open Paid Promote**\n"
        f"Info : @Mtchacream"
    )
    if thumb:
        try:
            logo = thumb
            await content.delete()
            msg = await bot.send_file(content.chat_id, logo, caption=output)
            await asyncio.sleep(300)
        except BaseException:
            await content.edit(
                output + "\n\n ***Logo yang diberikan tidak valid."
                "\nPastikan link diarahkan ke gambar logo**"
            )
    else:
        await edit_or_reply(content, output)
        
        
@zelda_cmd(pattern="cra (.*)")
async def amireallycontent(content):
    user = await bot.get_me()
    capt = str(content.pattern_match.group(1).split(" ", 2)[0])
    link = str(content.pattern_match.group(1).split(" ", 2)[1])
    capti = capt.replace(".", " ")
    thumb = rahimanget
    output = (
        f"**{capti}**\n\n"
        f"⬇️ KLIK UNTUK MENONTON ⬇️\n"
        f"{link}\n\n"
        f"-----------------------------------"
        f"\n📌 **Open Paid Promote**\n"
        f"Info : @Mtchacream"
    )
    if thumb:
        try:
            logo = thumb
            await content.delete()
            msg = await bot.send_file(content.chat_id, logo, caption=output)
            await asyncio.sleep(300)
        except BaseException:
            await content.edit(
                output + "\n\n ***Logo yang diberikan tidak valid."
                "\nPastikan link diarahkan ke gambar logo**"
            )
    else:
        await edit_or_reply(content, output)
        
        
@zelda_cmd(pattern="cps (.*)")
async def amireallycontent(content):
    user = await bot.get_me()
    capt = str(content.pattern_match.group(1).split(" ", 2)[0])
    link = str(content.pattern_match.group(1).split(" ", 2)[1])
    capti = capt.replace(".", " ")
    thumb = puresex
    output = (
        f"**{capti}**\n\n"
        f"⬇️ KLIK UNTUK MENONTON ⬇️\n"
        f"{link}\n\n"
        f"-----------------------------------"
        f"\n📌 **Open Paid Promote**\n"
        f"Info : @Mtchacream"
    )
    if thumb:
        try:
            logo = thumb
            await content.delete()
            msg = await bot.send_file(content.chat_id, logo, caption=output)
            await asyncio.sleep(300)
        except BaseException:
            await content.edit(
                output + "\n\n ***Logo yang diberikan tidak valid."
                "\nPastikan link diarahkan ke gambar logo**"
            )
    else:
        await edit_or_reply(content, output)
        
        
@zelda_cmd(pattern="cjm (.*)")
async def amireallycontent(content):
    user = await bot.get_me()
    capt = str(content.pattern_match.group(1).split(" ", 2)[0])
    link = str(content.pattern_match.group(1).split(" ", 2)[1])
    capti = capt.replace(".", " ")
    thumb = justmiss
    output = (
        f"**{capti}**\n\n"
        f"⬇️ KLIK UNTUK MENONTON ⬇️\n"
        f"{link}\n\n"
        f"-----------------------------------"
        f"\n📌 **Open Paid Promote**\n"
        f"Info : @Mtchacream"
    )
    if thumb:
        try:
            logo = thumb
            await content.delete()
            msg = await bot.send_file(content.chat_id, logo, caption=output)
            await asyncio.sleep(300)
        except BaseException:
            await content.edit(
                output + "\n\n ***Logo yang diberikan tidak valid."
                "\nPastikan link diarahkan ke gambar logo**"
            )
    else:
        await edit_or_reply(content, output)
        
@zelda_cmd(pattern="cbs (.*)")
async def amireallycontent(content):
    user = await bot.get_me()
    capt = str(content.pattern_match.group(1).split(" ", 2)[0])
    link = str(content.pattern_match.group(1).split(" ", 2)[1])
    capti = capt.replace(".", " ")
    thumb = babysweat
    output = (
        f"**{capti}**\n\n"
        f"⬇️ KLIK UNTUK MENONTON ⬇️\n"
        f"{link}\n\n"
        f"-----------------------------------"
        f"\n📌 **Open Paid Promote**\n"
        f"Info : @Mtchacream"
    )
    if thumb:
        try:
            logo = thumb
            await content.delete()
            msg = await bot.send_file(content.chat_id, logo, caption=output)
            await asyncio.sleep(300)
        except BaseException:
            await content.edit(
                output + "\n\n ***Logo yang diberikan tidak valid."
                "\nPastikan link diarahkan ke gambar logo**"
            )
    else:
        await edit_or_reply(content, output)
        
        
@zelda_cmd(pattern="ccb (.*)")
async def amireallycontent(content):
    user = await bot.get_me()
    capt = str(content.pattern_match.group(1).split(" ", 2)[0])
    link = str(content.pattern_match.group(1).split(" ", 2)[1])
    capti = capt.replace(".", " ")
    thumb = cussonsbaby
    output = (
        f"**{capti}**\n\n"
        f"⬇️ KLIK UNTUK MENONTON ⬇️\n"
        f"{link}\n\n"
        f"-----------------------------------"
        f"\n📌 **Open Paid Promote**\n"
        f"Info : @Mtchacream"
    )
    if thumb:
        try:
            logo = thumb
            await content.delete()
            msg = await bot.send_file(content.chat_id, logo, caption=output)
            await asyncio.sleep(300)
        except BaseException:
            await content.edit(
                output + "\n\n ***Logo yang diberikan tidak valid."
                "\nPastikan link diarahkan ke gambar logo**"
            )
    else:
        await edit_or_reply(content, output)

        
CMD_HELP.update(
    {
        "content": f"**Plugin : **`content_maker`\
        \n\n`.cdn` Dosa Nikmat.\
        \n`.ccn` Cuddle Nuddes.\
        \n`.ccc` Cream Cheese.\
        \n`.cra` Rahim Anget.\
        \n`.cps` Pure Sex.\
        \n`.cjm` Just Miss.\
        \n`.cbs` Baby Sweet.\
        \n`.ccb` Cussons Baby.\
    "
    }
)
